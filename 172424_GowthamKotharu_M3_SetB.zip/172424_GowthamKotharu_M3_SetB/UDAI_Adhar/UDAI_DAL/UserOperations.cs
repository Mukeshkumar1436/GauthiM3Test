﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using User_Entities;
using User_Exceptions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace UDAI_DAL
{
    public class UserOperations
    {
        public static UserEntity SearchUser(string AdharNo)
        {
            UserEntity user = null;

            try
            {
                SqlCommand cmd = UserConnection.GenerateCommand();

                cmd.CommandText = "user_Search_172424";
                cmd.Parameters.AddWithValue("@AdharNo", AdharNo);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    user = new UserEntity();
                    dr.Read();
                    user.FullName = dr["FullName"].ToString();
                    user.Gender = dr["Gender"].ToString();
                    user.DOB = Convert.ToDateTime(dr["DOB"]);
                    user.Address = dr["Address"].ToString();
                    user.City = dr["City"].ToString();
                    user.State = dr["State"].ToString();
                    user.Pincode = dr["Pincode"].ToString();
                    user.Email = dr["Email"].ToString();
                    user.Phone = dr["Phone"].ToString();
                }
                else
                {
                    throw new UserExceptions("Please Check Adhar Number, it's not correct.");
                }
                cmd.Connection.Close();
            }
            catch (UserExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }


        public static List<UserEntity> RetrieveUser()
        {
            List<UserEntity> userList = null;

            try
            {
                SqlCommand cmd = UserConnection.GenerateCommand();
                cmd.CommandText = "user_Details_172424";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    userList = new List<UserEntity>();
                    while (dr.Read())
                    {
                        UserEntity user = new UserEntity();

                        user.FullName = dr["FullName"].ToString();
                        user.Gender = dr["Gender"].ToString();
                        user.DOB = Convert.ToDateTime(dr["DOB"]);
                        user.Address = dr["Address"].ToString();
                        user.City = dr["City"].ToString();
                        user.State = dr["State"].ToString();
                        user.Pincode = dr["Pincode"].ToString();
                        user.Email = dr["Email"].ToString();
                        user.Phone = dr["Phone"].ToString();

                        userList.Add(user);
                    }
                }
                else
                    throw new UserExceptions("Record not available");
                cmd.Connection.Close();
            }
            catch (UserExceptions ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userList;
        }
        public static int UpdateUser(UserEntity user)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = UserConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "user_Update_172424";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@AdharNo", user.AdharNumber);
                cmd.Parameters.AddWithValue("@Address", user.Address);
                cmd.Parameters.AddWithValue("@City", user.City);
                cmd.Parameters.AddWithValue("@State", user.State);
                cmd.Parameters.AddWithValue("@Pincode", user.Pincode);
                cmd.Parameters.AddWithValue("@Email", user.Email);
                cmd.Parameters.AddWithValue("@Phone", user.Phone);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
