﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace User_Exceptions
{
    public class UserExceptions  : Exception
    {
        public UserExceptions() : base()
        {

        }
        public UserExceptions(string message) : base(message)
        {

        }
    }
}
