﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UDAI_DAL;
using User_Entities;
using User_Exceptions;
using System.Text.RegularExpressions;

namespace UDAI_BAL
{
    public class UDAIBAL
    {

        public static bool ValildateUser(UserEntity user)
        {
            bool userValidation = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (!Regex.IsMatch(user.AdharNumber, "[0-9]{12}"))
                {
                    userValidation = true;
                    
                }
                else
                {
                    message.Append("Please Check Adhar Number, it's not correct.");
                }

            //    if (user.SName == String.Empty)
            //    {
            //        studValidated = false;
            //        message.Append("Student name should be provided\n");
            //    }
            //    else if (!Regex.IsMatch(stud.SName, "[A-Z][a-z]+"))
            //    {
            //        studValidated = false;
            //        message.Append("Student Name should Start with Capitals only\n");
            //    }

            //    if (stud.Dob == null)
            //    {
            //        studValidated = false;
            //        message.Append("Student Date of Birth should be provided\n");
            //    }

            //    if (studValidated == false)
            //        throw new Student_Exce(message.ToString());
            }
            catch (UserExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidation;
        }


        public static UserEntity SearchUser(string AdharNumber)
        {
            UserEntity user = null;

            try
            {
                user = UserOperations.SearchUser(AdharNumber);
            }
            catch (UserExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return user;
        }

        public static int UpdateUser(UserEntity user)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateUser(user))
                {
                    recordsAffected = UserOperations.UpdateUser(user);
                }
                else
                    throw new UserExceptions("Please provide valid User Information");
            }
            catch (UserExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
    }
}
