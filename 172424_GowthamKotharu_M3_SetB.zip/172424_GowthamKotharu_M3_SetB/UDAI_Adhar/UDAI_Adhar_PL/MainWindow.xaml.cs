﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using UDAI_BAL;
using User_Entities;
using User_Exceptions;

namespace UDAI_Adhar_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void show()
        {
            txtFullName.IsEnabled = false;
            txtGender.IsEnabled = false;
            txtDOB.IsEnabled = false;
            lblFullName.Visibility = 0;
            lblGender.Visibility = 0;
            lblDOB.Visibility = 0;
            lblAddress.Visibility = 0;
            lblCity.Visibility = 0;
            lblState.Visibility = 0;
            lblPincode.Visibility = 0;
            lblEmail.Visibility = 0;
            lblPhNo.Visibility = 0;

            txtFullName.Visibility = 0;
            txtGender.Visibility = 0;
            txtDOB.Visibility = 0;
            txtAddress.Visibility = 0;
            txtCity.Visibility = 0;
            txtState.Visibility = 0;
            txtPincode.Visibility = 0;
            txtEmail.Visibility = 0;
            txtPhNo.Visibility = 0;

            btnUpdate.Visibility = 0;
        }
        
        private void GetDetails_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                string AdharNo = txtAdharNo.Text;

                UserEntity user = UDAIBAL.SearchUser(AdharNo);

                if (user != null)
                {
                    txtFullName.Text = user.FullName;
                    txtGender.Text = user.Gender;
                    txtDOB.Text = user.DOB.ToString();
                    txtAddress.Text = user.Address;
                    txtCity.Text = user.City;
                    txtState.Text = user.State;
                    txtPincode.Text = user.Pincode;
                    txtEmail.Text = user.Email;
                    txtPhNo.Text = user.Phone;


                    show();

                }
                else
                    throw new UserExceptions("Please Check Adhar Number, it's not correct.");
            }
            catch (UserExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void GetUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                UserEntity user = new UserEntity();
                user.AdharNumber = txtAdharNo.Text;
                user.Address = txtAddress.Text;
                user.City = txtCity.Text;
                user.State = txtState.Text;
                user.Pincode = txtPincode.Text;
                user.Email = txtEmail.Text;
                user.Phone = txtPhNo.Text;

                int recordsAffected = UDAIBAL.UpdateUser(user);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                   
                }
                else
                    throw new UserExceptions("Record not updated");
            }
            catch (UserExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
