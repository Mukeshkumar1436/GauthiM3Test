USE Training_23Jan19_Pune

CREATE TABLE UDAI_Adhar_172424(
AdharNumber varchar(12) primary key ,
FullName varchar(30),
Gender varchar(8),
DOB date,
Address varchar(50),
City varchar(15),
State varchar(20),
Pincode varchar(6),
Email varchar(30),
Phone varchar(10)
)
GO

DELETE TABLE UDAI_Adhar_172424

SELECT * FROM UDAI_Adhar_172424
GO

INSERT INTO UDAI_Adhar_172424
VALUES('569397954986','Gowtham Kotharu','Male','05/20/1996','Gowripatnam','WestGodavari','AP','534313','gautam@gmail.com','8008534979')

INSERT INTO UDAI_Adhar_172424
VALUES('269397954987','bhargav Kotharu','Male','01/01/1995','Gowripatnam','WestGodavari','AP','534313','bhargav@gmail.com','9865472547'),
('169397954988','Jyothi Kotharu','Female','01/01/1985','Gowripatnam','WestGodavari','AP','534313','jyothi@gmail.com','9865489547'),
('769397954987','Nagu Kotharu','Male','01/01/1981','Gowripatnam','WestGodavari','AP','534313','Nagu@gmail.com','9865472897')

CREATE PROC user_Search_172424
(
	@AdharNo		varchar(12)
)
AS
BEGIN
	SELECT * FROM UDAI_Adhar_172424
	WHERE AdharNumber = @AdharNo
END

GO

CREATE PROC user_Update_172424(
@AdharNo varchar(12),
@Address varchar(50),
@City varchar(15),
@State varchar(20),
@Pincode varchar(6),
@Email varchar(30),
@Phone varchar(10)
)
AS
BEGIN
UPDATE UDAI_Adhar_172424
SET Address = @Address,
	City = @City,
	State = @State,
	Pincode = @Pincode,
	Email = @Email,
	Phone = @Phone
	WHERE AdharNumber = @AdharNo
END
go

CREATE PROC user_Details_172424
AS
BEGIN
	SELECT * FROM UDAI_Adhar_172424
END

GO


